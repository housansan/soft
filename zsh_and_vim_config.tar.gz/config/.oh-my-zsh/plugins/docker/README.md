## Docker autocomplete plugin

A copy of the completion script from the
[docker/cli](https://github.com/docker/cli/blob/master/contrib/completion/zsh/_docker)
git repo.
